Thanks for stopping by to let us know something could be better!

Please be sure to include as much information as possible:

#### Environment details

- OS:
- Java version:
- google-api-java-client version:

#### Steps to reproduce

1. ?
2. ?

#### Stacktrace

```
Any relevant stacktrace here.
```

#### External references such as API reference guides used

- ?

#### Any additional information below

Making sure to follow these steps will guarantee the quickest resolution possible.

Thanks!

